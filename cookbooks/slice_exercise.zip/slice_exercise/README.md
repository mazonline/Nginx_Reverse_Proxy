# slice_exercise

"Write a chef cookbook that deploys Apache tomcat with an Nginx reverse proxy. The Nginx reverse proxy sits in front of tomcat and does SSL termination. A user requesting content from Nginx should see a simple Apache tomcat test page."
